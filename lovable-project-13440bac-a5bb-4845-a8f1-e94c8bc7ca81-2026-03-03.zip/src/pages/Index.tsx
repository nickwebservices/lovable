import Hero from "@/components/Hero";
import Mission from "@/components/Mission";
import Library from "@/components/Library";
import Contact from "@/components/Contact";

const Index = () => {
  return (
    <main className="min-h-screen">
      <Hero />
      <Mission />
      <Library />
      <Contact />
      
      <footer className="py-8 border-t border-border/50">
        <div className="container px-4 text-center text-muted-foreground">
          <p>&copy; 2025 Music Creators Support. Empowering local artists worldwide.</p>
        </div>
      </footer>
    </main>
  );
};

export default Index;
