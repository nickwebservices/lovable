import { Button } from "@/components/ui/button";
import { Music, Play } from "lucide-react";
import { motion } from "framer-motion";
import AnimatedBackground from "./AnimatedBackground";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      <AnimatedBackground />
      
      <div className="container relative z-10 px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <motion.div 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-hero border border-primary/20 backdrop-blur-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Music className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Empowering Local Artists</span>
          </motion.div>
          
          <motion.h1 
            className="text-6xl md:text-8xl font-bold tracking-tight"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <span className="block text-foreground drop-shadow-[0_0_20px_rgba(0,255,255,0.8)]">
              AMPLIFY YOUR
            </span>
            <motion.span 
              className="block bg-gradient-primary bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(255,0,255,0.6)] mt-2"
              animate={{ 
                textShadow: [
                  "0 0 20px hsl(var(--primary))",
                  "0 0 40px hsl(var(--accent))",
                  "0 0 20px hsl(var(--primary))"
                ]
              }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              ROCK REVOLUTION
            </motion.span>
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Supporting independent music creators with the resources, platform, and community to share their passion with the world.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <Button variant="hero" size="lg" className="group">
              Get Started
              <Play className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="outline" size="lg">
              Explore Library
            </Button>
          </motion.div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-10" />
    </section>
  );
};

export default Hero;
