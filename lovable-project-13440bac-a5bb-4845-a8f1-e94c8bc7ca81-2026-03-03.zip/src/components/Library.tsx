import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Newspaper, Rocket, Podcast, ArrowRight } from "lucide-react";

const Library = () => {
  const libraryItems = [
    {
      icon: Newspaper,
      category: "News",
      title: "Industry Updates & Artist Features",
      description: "Stay informed with the latest music industry trends, artist spotlights, and community success stories.",
      badge: "Updated Daily",
      color: "text-primary",
    },
    {
      icon: Rocket,
      category: "New Launches",
      title: "Fresh Releases & Platform Features",
      description: "Discover newly launched tracks, albums, and innovative tools we're adding to support creators.",
      badge: "New This Week",
      color: "text-secondary",
    },
    {
      icon: Podcast,
      category: "Podcasts",
      title: "Creator Conversations & Tips",
      description: "Listen to inspiring interviews with successful artists and expert advice on building your music career.",
      badge: "Weekly Episodes",
      color: "text-accent",
    },
  ];

  return (
    <section className="py-24">
      <div className="container px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Resource Library
          </h2>
          <p className="text-lg text-muted-foreground">
            Access a wealth of knowledge, inspiration, and updates to fuel your musical journey.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {libraryItems.map((item, index) => (
            <Card
              key={index}
              className="group hover:shadow-glow transition-all duration-300 border-border/50 overflow-hidden"
            >
              <CardHeader>
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                    <item.icon className="w-7 h-7 text-primary-foreground" />
                  </div>
                  <Badge className="font-medium bg-accent text-white border-transparent">
                    {item.badge}
                  </Badge>
                </div>
                <CardTitle className="text-2xl mb-2">{item.title}</CardTitle>
                <CardDescription className="text-base">
                  {item.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="w-full justify-between group/btn">
                  Explore {item.category}
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Library;
