import { Heart, Users, Mic, Radio } from "lucide-react";

const Mission = () => {
  const features = [
    {
      icon: Heart,
      title: "Passionate Support",
      description: "We believe in the power of local talent and provide dedicated resources to help artists thrive.",
    },
    {
      icon: Users,
      title: "Community First",
      description: "Building a vibrant community where creators connect, collaborate, and grow together.",
    },
    {
      icon: Mic,
      title: "Creative Freedom",
      description: "Empowering artists to maintain their authentic voice while reaching wider audiences.",
    },
    {
      icon: Radio,
      title: "Platform Access",
      description: "State-of-the-art tools and distribution channels to amplify your music globally.",
    },
  ];

  return (
    <section className="py-24 bg-muted/30">
      <div className="container px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Our Mission
          </h2>
          <p className="text-lg text-muted-foreground">
            We're dedicated to creating a sustainable ecosystem where independent music creators can flourish. 
            Our platform provides the support, tools, and community needed to turn musical passion into a thriving career.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group p-6 rounded-2xl bg-card shadow-card hover:shadow-glow transition-all duration-300 border border-border/50"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Mission;
